MAKAZ Android WebView Project (practice demo)
==============================================

This is Android app SOURCE CODE, not a precompiled APK.

Build an APK:
1. Install Android Studio on a computer.
2. Open this extracted project folder (MAKAZ_Android_Project).
3. Let Gradle sync. Install Android SDK Platform 35 if Android Studio asks.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK path, normally:
   app/build/outputs/apk/debug/app-debug.apk

Demo features: colour buttons, countdown, simulated results, virtual coins, history,
demo admin screen and practice profile.

Limits: no real user authentication, backend/database, secure production admin panel,
real payments, deposits, withdrawals or real-money betting. Admin PIN is only a demo UI gate.
